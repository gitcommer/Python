from django.shortcuts import render, redirect
from crudapplication.forms import EmployeeForm
from crudapplication.models import Employee

def emp(request):
	# if naay gi send na data
	if request.method == "POST":
		form = EmployeeForm(request.POST)
		if form.is_valid():
			try:
				form.save()
				return redirect("/show")
			except:
				pass
	else:
		# if wlay gi send na data display this
		form = EmployeeForm()  # forms.py, class EmployeeForm(forms.ModelForm):
	return render(request,"index.html",{'form':form})

def show(request):
	employees = Employee.objects.all()  # SELECT * FROM models.py, class Employee
	return render(request,"show.html", {'employees' : employees})

def edit(request, id):
	employee = Employee.objects.get(id=id)  # get only the id
	return render(request, "edit.html", {'employee' : employee})

def update(request, id):
	employee = Employee.objects.get(id=id)
	form = EmployeeForm(request.POST, instance = employee)
	if form.is_valid():
		form.save()
		return redirect('/show')
	return render(request, "edit.html", {'employee' : employee})

def delete(request, id):
	employee = Employee.objects.get(id=id)
	employee.delete()
	return redirect("/show")


