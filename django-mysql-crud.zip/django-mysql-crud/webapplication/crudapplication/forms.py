from django import forms
from crudapplication.models import Employee  # database

class EmployeeForm(forms.ModelForm):
	class Meta:
		model = Employee  # is in models.py/class Employee()
		fields = "__all__"  # get all data in columns