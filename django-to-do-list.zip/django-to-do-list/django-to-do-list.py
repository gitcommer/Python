date: july 16, 2019
tutorial: https://www.youtube.com/watch?v=fEqOW6FrokA

find:	- ang pag register sa new app kay adto sa settings.py sa mother app
		- child app - display string home.html in browser
		- include basa.html to home.html
		- link
		- database
		- insert
		- delete
		- cross_off and uncross
		- edit



link
----
base.html 	- <a class="navbar-brand" href="{% url 'home' %}">To-Do List</a>  # logo link to home.html page
			- <td class="striker"><a href="{% url 'edit' things.id %}">{{ things.item }}</a></td>  # link edit.html with id


database
--------
todo_list/models.py 	- from django.db import models

						class List(models.Model):  # List is table name
							item = models.CharField(max_length=200)  # item is column name
							completed = models.BooleanField(default=False)

							def __str__(self):
								return self.item + ' | ' + str(self.completed)  # return variable item and completed to browser

						- python manage.py makemigrations
						- python manage.py migrate  # this will create 0001_initial.py in todo_list/migrations



1	- cmd/pip install virtualenv - Include, Lib, Scripts, tcl - mao ni ang mga virtual environment
	- virtualenv . - this code will turn on the virtualenv

	- .\Scripts\activate - (django) naay ingon ani sa cmd meaning this code will turn on the virtualenv

2	- create django_app folder inside django-to-do-list folder as your new app
		- pip install django 				- install django in django_app folder (wla kay file makit-an inig install ani)
		- pip freeze		 				- this will make sure that django is installed
		- django-admin.py startproject todo - create django project inside django_app folder
 		- python manage.py runserver

 		- django_app/todo python manage.py migrate
 		- django_app/todo python manage.py startapp todo_list - create app and name todo_list inside to do folder


3 	- ang pag register sa new app kay adto sa settings.py sa mother app

	01	INSTALLED_APPS = [
		    'django.contrib.staticfiles',
		    'todo_list',  # this is the child app folder name
		]

	02	from django.contrib import admin
		from django.urls import path, include  #1 include the path of todo_list app
		from todo_list import views  #1 import the views.py of todo_list app

		urlpatterns = [
		    path('admin/', admin.site.urls),
		    path('', include('todo_list.urls')),  #1 include the urls.py of todo_list app
		]


4 	- child app - display html in browser

	todo_list/templates/home.html 	"Hello World!"


	todo_list/views.py 		from django.shortcuts import render

							def home(request):
								return render(request, 'home.html', {})


	todo_list/urls.py 	from django.urls import path
						from . import views

						urlpatterns = [
						    path('', views.home, name="home"),  # name="home" or home.html
						]


include base.html to home.html
------------------------------
home.html 	- {% extends 'base.html' %}
			- {% block content %}
			  {% endblock %}

base.html 	- {% block content %}
			  {% endblock %}



insert
------
database: 	todo_list/models.py 	- from django.db import models

									class List(models.Model):  # List is table name
										item = models.CharField(max_length=200)  # item is column name
										completed = models.BooleanField(default=False)

										def __str__(self):
											return self.item + ' | ' + str(self.completed)  # return variable item and completed to browser

									- python manage.py makemigrations
									- python manage.py migrate  # this will create 0001_initial.py in todo_list/migrations


todo_list/base.html		<form class="form-inline my-2 my-lg-0" method="POST">

						  {% csrf_token %}

						  <input class="form-control mr-sm-2" type="search" placeholder="Add Item" aria-label="Search" name="item">
						  <button class="btn btn-outline-secondary my-2 my-sm-0" type="submit">Add to list</button>
						</form>


todo_list/home.html		{% extends 'base.html' %}

							{% block content %}

								###display message

								{% if messages %}
									{% for message in messages %}

										<div class="alert alert-warning alert-dismessable" role="alert">
											<button class="close" data-dismiss="alert">
												<small><sup>x</sup></small>
											</button>
											{{ message }}
										</div>

									{% endfor %}
								{% endif %}

								###display database data

								{% if all_items %}
									<table class="table table-bordered">
										{% for things in all_items %}
											{% if things.completed %}
												<tr class="table-secondary">
													<td class="striker"><a href="{% url 'edit' things.id %}">{{ things.item }}</a></td>
													<td><center><a href="{% url 'uncross' things.id %}">Uncross</a></center></td>
													<td><center><a href="{% url 'delete' things.id %}">Delete</a></center></td>
												</tr>
											{% else %}
												<tr>
													<td><a href="{% url 'edit' things.id %}">{{ things.item }}</a></td>
													<td><center><a href="{% url 'cross_off' things.id %}">Cross Off</a></center></td>
													<td><center><a href="{% url 'delete' things.id %}">Delete</a></center></td>
												</tr>
											{% endif %}

										{% endfor %}
									</table>
								{% endif %}

						{% endblock %}



todo_list/views.py 		from django.shortcuts import render, redirect
						from . models import List
						from . forms import ListForm
						from django.contrib import messages  # success message

						#insert
						def home(request):
							if request.method == 'POST':
								form = ListForm(request.POST or None)

								if form.is_valid():
									form.save()
									all_items = List.objects.all  # get all data from database
									messages.success(request, ('Item Has Been Added To List'))
									return render(request, 'home.html', {'all_items': all_items})  # display new added data

							else:
								all_items = List.objects.all
								return render(request, 'home.html', {'all_items': all_items})  # display all data


todo_list/forms.py 		from django import forms
						from . models import List

						class ListForm(forms.ModelForm):
							class Meta:
								model = List
								fields = ["item", "completed"]



delete - when click delete, delete the data and display delete message
------
todo_list/home.html		<table class="table table-bordered">
							{% for things in all_items %}
								{% if things.completed %}
									<tr class="table-secondary">
										<td class="striker"><a href="{% url 'edit' things.id %}">{{ things.item }}</a></td>
										<td><center><a href="{% url 'uncross' things.id %}">Uncross</a></center></td>
										<td><center><a href="{% url 'delete' things.id %}">Delete</a></center></td>  #01
									</tr>
								{% else %}
									<tr>
										<td><a href="{% url 'edit' things.id %}">{{ things.item }}</a></td>
										<td><center><a href="{% url 'cross_off' things.id %}">Cross Off</a></center></td>
										<td><center><a href="{% url 'delete' things.id %}">Delete</a></center></td>  #01
									</tr>
								{% endif %}

							{% endfor %}
						</table>


todo_list/views.py 		def delete(request, list_id):  #01
							item = List.objects.get(pk=list_id)
							item.delete()
							messages.success(request, ('Item Has Beed Deleted'))
							return redirect('home')


todo_list/urls.py		from django.urls import path
						from . import views

						urlpatterns = [
						    path('', views.home, name="home"),
						    path('delete/<list_id>', views.delete, name="delete"),  #01
						    path('cross_off/<list_id>', views.cross_off, name="cross_off"),
						    path('uncross/<list_id>', views.uncross, name="uncross"),
						    path('edit/<list_id>', views.edit, name="edit"),
						]



cross_off and uncross
*********************
todo/static/css/my_css.css 		.striker{
									text-decoration: line-through;
								}



todo_list/home.html		<table class="table table-bordered">
							{% for things in all_items %}
								{% if things.completed %}
									<tr class="table-secondary">
										<td class="striker"><a href="{% url 'edit' things.id %}">{{ things.item }}</a></td>
										<td><center><a href="{% url 'uncross' things.id %}">Uncross</a></center></td>
										<td><center><a href="{% url 'delete' things.id %}">Delete</a></center></td>  #01
									</tr>
								{% else %}
									<tr>
										<td><a href="{% url 'edit' things.id %}">{{ things.item }}</a></td>
										<td><center><a href="{% url 'cross_off' things.id %}">Cross Off</a></center></td>
										<td><center><a href="{% url 'delete' things.id %}">Delete</a></center></td>  #01
									</tr>
								{% endif %}

							{% endfor %}
						</table>



todo_list/views.py 		def cross_off(request, list_id):  #01
							item = List.objects.get(pk=list_id)
							item.completed = True
							item.save()
							return redirect('home')

						def uncross(request, list_id):  #01
							item = List.objects.get(pk=list_id)
							item.completed = False
							item.save()
							return redirect('home')



todo_list/urls.py		from django.urls import path
						from . import views

						urlpatterns = [
						    path('', views.home, name="home"),
						    path('delete/<list_id>', views.delete, name="delete"),
						    path('cross_off/<list_id>', views.cross_off, name="cross_off"),  #01
						    path('uncross/<list_id>', views.uncross, name="uncross"),  #01
						    path('edit/<list_id>', views.edit, name="edit"),
						]



edit
****
todo_list/edit.html 	{% if item %}
							<form class="form-inline my-2 my-lg-0" method="POST">
								{% csrf_token %}
								<input class="form-control mr-ms-2" type="search" placeholder="{{ item.item }}" value="{{ item.item }}" aria-label="Search" name="item">
								<input type="hidden" value="{{ item.completed }}" name="completed">
								<button class="btn btn-outline-secondary my-2 my-sm-0" type="submit">Edit Item</button>
							</form>
						{% endif %}


todo_list/urls.py		from django.urls import path
						from . import views

						urlpatterns = [
						    path('', views.home, name="home"),
						    path('delete/<list_id>', views.delete, name="delete"),
						    path('cross_off/<list_id>', views.cross_off, name="cross_off"),  #01
						    path('uncross/<list_id>', views.uncross, name="uncross"),  #01
						    path('edit/<list_id>', views.edit, name="edit"),
						]
