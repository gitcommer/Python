

#----- firstproject/urls.py -----

from django.conf.urls import url  # this is the library for url
from django.contrib import admin  # this is the library for admin user
from . import views  # call views.py

urlpatterns = [
    url(r'^admin/', admin.site.urls),  # this is how you use the library from django.conf.urls import url
    url(r'^about/$', views.about),  # views.py/def about
    url(r'^$', views.homepage),  # default home page
]


#----- firstproject/views.py -----

from django.http import HttpResponse  # this library will response user request like mo adto ang user sa about page this will send the about page

def homepage(request):
    return HttpResponse('homepage')

def about(request):
    return HttpResponse('about')


# python manage.py runserver
# localhost:8000/about