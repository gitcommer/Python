#1 	add this to articlesproject/urls.py

	urlpatterns = [
		url(r'^$', views.article_list),
		url(r'^(?P<slug>[\w-]+)/$', views.article_detail), 	#01
	]

#2 	add this to articlesproject/views.py

	from django.http import HttpResponse	#001 add this on the top

	def article_detail(request, slug):	#002 add this on the bottom
		return HttpResponse(slug)