#1	accounts/urls.py

	from django.conf.urls import url  # this is the library use for url or path in address bar
	from.import views  # views.py this will call the html page

	app_name = 'accounts'

	urlpatterns = [
		url(r'^signup/$',views.signup_view,name="signup"),
		url(r'^login/$',views.login_view,name="login"),  #01
		url(r'^logout/$',views.logout_view,name="logout"),  #03	
	]


#2	accounts/views.py

	from django.shortcuts import render  # this is the library for request
	from django.contrib.auth.forms import UserCreationForm  # this is library for forms
	from django.auth import login, logout  #02 & #3 login specific user and logout library

	# Create your views here.
	def signup_view(request):

		if request.method == 'POST':  # POST means if the data is from forms
			form = UserCreationForm(request.POST)
			if form.is_valid():  # if forms is valid or no error
				user = form.save()  #02 login specific user
				login(request, user)  #02 login specific user
				return redirect('articles:list')
			else:
				form = UserCreationForm()
			return render(request,'accounts/signup.html',{'form':form})  # {'form':form} means form now will send to html


	#01 start login-----------------------

	def login_view(request):
		if request.method == 'POST':
			form = AuthenticationForm(data=request.POST)
			if form.is_valid(): 
				user = form.get_user()  #02 login specific user
				login(request, user)  #02 login specific user
				return redirect('articles:list')
		else:
			form = AuthenticationForm()
		return render(request, 'accounts/login.html',{'form':form})

	#01 end login-----------------------



	#03 start logout-----------------------
	def logout_view(request):
		if request.method == 'POST':
			logout(request)
			return redirect('articles:list')
	#03 end logout-----------------------


#3	accounts/templates/accounts/login.html

	{% extends 'base_layout.html' %}

	{% block content %}
		<h1>Signup</h1>
		<!--<form class="site-form" action="/accounts/login/" method="post">-->
		<!-- #or -->
		<form class="site-form" action="{% url'accounts:login' %}" method="post">

			{{ csrf_token }}  <!-- forms security -->
			{{ form }}
			<input type="submit" value="Login">
		</form>
	{% endblock %}


#4 firsproject/templates/base_layout.html

	<nav>
		<ul>
			<li>
				<form class="logout" action="{% url'accounts:logout' %}" method="post">
					{% csrf_token %}
					<button type="submit">Logout</button>
				</form>
			</li>
		</ul>
	</nav>






