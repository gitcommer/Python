#1	cmd/python manage.py startapp accounts	- this will create accounts folder in mainfolder


#2 	firstproject/settings.py - add this in the bottom of INSTALLED_APPS = [ like
	
		INSTALLED_APPS = [
		    'django.contrib.staticfiles',
		    'articles',  
		    'accounts',  #01 or accounts folder
		]


#3 	create urls.py inside accounts folder

	from django.conf.urls import url  # this is the library use for url or path in address bar
	from.import views  # views.py this will call the html page

	app_name = 'accounts'

	urlpatterns = [
		url(r'^signup/$',views.signup_view,name="signup")  # this is the path in url address bar


#4 	firstproject/urls.py
	
	# NOTE: i sunod tanan like naay / sa last like admin/ or accounts/ or articles/

	from django.conf.urls import url, include
	from django.contrib import admin
	from.import views
	from django.contrib.staticfiles.urls import staticfiles_urlpatterns
	from django.conf.urls.static import static 
	from django.conf import settings  

	urlpatterns = [
	    url(r'^admin/', admin.site.urls),
	    url(r'^accounts/',include('accounts.urls')),  #01 this means include or register the file accounts/urls.py
	    url(r'^articles/', include('articles.urls')),
	    url(r'^about/$',views.about),
	    url(r'^$', views.homepage),
	]

	urlpatterns += staticfiles_urlpatterns()

	# note:	- setting.MEDIA_URL - is the url appear in the address bar
	# 		- document_root=settings.MEDIA_ROOT - the folder where images are save

	urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)


#5	accounts/views.py

	from django.shortcuts import render  # this is the library for request
	from django.contrib.auth.forms import UserCreationForm  # this is library for forms

	# Create your views here.
	def signup_view(request):

		if request.method == 'POST':  # POST means if the data is from forms
			form = UserCreationForm(request.POST)
			if form.is_valid():  # if forms is valid or no error
				form.save()  # save to database
				return redirect('articles:list')
			else:
				form = UserCreationForm()
			return render(request,'accounts/signup.html',{'form':form})  # {'form':form} means form now will send to html


#6 	create 2 folder in accounts like templates/accounts/signup.html
	
	{% extends 'base_layout.html' %}

	{% block content %}
		<h1>Signup</h1>
		<form class="site-form" action="/accounts/signup/" method="post">
			{{ csrf_token }}  <!-- forms security -->
			{{ form }}
			<input type="submit" value="Signup">
		</form>
	{% endblock %}

#7 	python manage.py runserver

#8 	localhost:8000/accounts/signup/

	