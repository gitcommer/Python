
# NOTE: this program will add upload file in user dashboard and display the image to browser


#1	firstproject/settings.py add this code the bottom

	MEDIA_URL = '/media/'  # or pics or whatever you like, this url appear in the address bar
	MEDIA_ROOT = os.part.join(BASE_DIR. 'media')  # the folder path where image is save


#2 firstproject/urls.py

	from django.conf.urls import url, include
	from django.contrib import admin
	from.import views
	from django.contrib.staticfiles.urls import staticfiles_urlpatterns
	from django.conf.urls.static import static  #01
	from django.conf import settings  #01

	urlpatterns = [
	    url(r'^admin/', admin.site.urls),
	    url(r'^articles/', include('articles.urls')),
	    url(r'^about/$',views.about),
	    url(r'^$', views.homepage),
	]

	urlpatterns += staticfiles_urlpatterns()

	# note:	- setting.MEDIA_URL - is the url appear in the address bar
	# 		- document_root=settings.MEDIA_ROOT - the folder where images are save

	urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)  #01


#3 articles/models.py

	# NOTE: EVERYTIME YOU MAKE CHANGES HERE UPDATE THE DATABASE like python manage.py makemigrations

	from django.db import models

	class Article(models.Model):
		title = models.CharField(max_length=100)
		slug = models.SlugField()
		body = models.TextField()
		date = models.DateTimeField(auto_now_add=True)
		thumb = models.ImageField(default='default.png', blank=True)  #01 if no image this image will display

		def __str__(self):
			return self.title

		def snippet(self):
			return self.body[:50] + '...'


#4 articles/template/articles/article_detail.py

	{% extends 'base_layout.html' %}

	{% block content %}
	<div class="article-detail">
		<div class="article">
			<img src="{{ article.thumb.url }}">  <!-- #01 display image here -->
			<h2>{{ article.title }}</h2>
			<p>{{ article.body }}</p>
			<p>{{ article.date }}</p>
		</div>
	</div>
	{% endblock %}


#5 install pillow like cmd/pip install Pillow

#6 python manage.py makemigrations

#7 python manage.py migrate

#8 python manage.py runserver

#9 refresh the articles dashboard