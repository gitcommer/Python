
#-----urls.py-----

from django.conf.urls import url
from django.contrib import admin
from . import views  # from. meaning si views.py same ra og folder ni urls.py

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^about/$', views.about),
    url(r'^$', views.homepage),  #default home page
]


#-----views.py-----

from django.http import HttpResponse
from django.shortcuts import render  # this library will call html

def homepage(request):
    # return HttpResponse('homepage')  # display strings
    return render(request, 'homepage.html')  # display html

def about(request):
    # return HttpResponse('about')  # display strings
    return render(request, 'about.html')  # display html


# 03. create templates(folder)/homepage.html

<!DOCTYPE html>
<html>
<head>
	<title>Homepage</title>
</head>
<body>
	<h1>This is the HomePage</h1>
	<p>Welcome to Django</p>
</body>
</html>


# 04. create templates(folder)/about.html

<!DOCTYPE html>
<html>
<head>
	<title>About</title>
</head>
<body>
	<h1>About Us</h1>
	<p>We love Django</p>
</body>
</html>


# 05. go to projectfolder/settings.py and find

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],  # add here like 'DIRS': ['templates'],


# python manage.py runserver
# localhost:8000/about