9. create admin user and import the data of other project to admin user
***********************************************************************
1.	- python manage.py runserver
	- localhost:8000/admin
	- python manage.py createsuperuser 		# register user using console
	- python manage.py runserver

2. 	- articles articles/admin.py and add
	- from.models import Article 	# add this on top
	- admin.site.register(Article)	# add this on body

	note: what will happen here kay ma register si article project sa djangonautic makita nimo
		  sa dashboard sa other project and data
		  - green check in STAFF STATUS is the admin user