#01	 	- add article forms data to admin like title, slug, body


#2		- articles/models.py
		
		from django.db import models

		# Create your models here.
		class Article(models.Model):
			title = models.CharField(max_length=100)
			slug = models.SlugField()
			body = models.TextField()
			date = models.DateTimeField(auto_now_add=True)

			def __str__(self):
				return self.title

			def snippet(self):
				return self.body[:50] + '...' #02 display only 0-50 character in body


#3		- articles/article_list.py

		<!DOCTYPE html>
		<html>
		<head>
			<title>Article List</title>
		</head>
		<body>
			<h1>Article List</h1>
			<div class="article">
				{% for article in articles %}
					<div class="article">
						<h2><a href="#">{{ article.tile }}</a></h2>
						<p><a href="#">{{ article.snippet }}</a></p>  #03
						<p><a href="#">{{ article.date }}</a></p>
					</div>
				{% endfor %}
			</div>
		</body>
		</html>


#		note:	{% code %} 		- use this for python code
#			 	{{ db data }}	- use this to output database data

#		output data: localhost:8000/articles


#4		- articles/views.py
		
		from django.shortcuts import render
		from .models import Article

		def article_list(request):

			articles = Article.objects.all.order_by('date')
			return render(request, 'articles/article_list.html', {'articles':articles})
