# to study: 9

# error: 	invalid systax 		- naay kowang ang code

# MODELS or Database
# GET - receive request from a server like type url in an address bar
# POST - sending request to the server and creating new record to the server like sending forms data

# __init__.py 	- is the modules
# urls.py 		- controllers
# views 			- __pycache__ (folder)
# ^admin$ 		- ^ means the start of the strings and $ is the end of the strings
# ctrl + c - to stop run
# create and link pages
# database

# install django
# create django project
# run django






# 2. install django
# *****************
# open cmd - C:\Users\TAE\Desktop\django-notes - pip install django

# create django project
# ---------------------
# open cmd - C:\Users\TAE\Desktop\django-notes - django-admin startproject djangoproject

# run django
# ----------
# open cmd - C:\Users\TAE\Desktop\django-notes\djangoproject - python manage.py runserver

# 3. urls and views
# *****************

# database
#*********
# - when you run python manage.py runserver this will create automatically the db.sqlite database



# 9. create admin user and import the data of other project to admin user
# ***********************************************************************
# 1.	- python manage.py runserver
# 	- localhost:8000/admin
# 	- python manage.py createsuperuser 		# register user using console
# 	- python manage.py runserver

# 2. 	- articles (new project folder)/admin.py and add
# 	- from.models import Article 	# add this on top
# 	- admin.site.register(Article)	# add this on body

# 	note: what will happen here kay ma register si article project sa other prject makita nimo
# 		  sa dashboard sa other project and data


# models or database
# ******************
# NOTE: EVERYTIME YOU MAKE CHANGES HERE UPDATE THE DATABASE like python manage.py makemigrations





#---------- #24 requiring login - user cannot see the post withot loging in ----------

# articles/urls.py 	

		url(r'^create/$', views.article_create, name="create"),  #24-1


# articles/views.py

		from django.contrib.auth.decorators import login_required  #24-2

		#24-2 start ----------------

		@login_required(login_url="/accounts/login/")  #24-2 if not login redirect	 to accounts\templates\accounts\login.html

		def article_create(request):
		    return render(request, 'articles/article_create.html')

		#24-2 end -----------------


# articles/article_create.html

		<!--#24-3 start --------------->

		{% extends 'base_layout.html' %}

		{% block content %}
		    <div class="create-article">
		        <h2>Create an Awesome New Article</h2>

		    </div>
		{% endblock %}





#---------- #25 redirect after login ----------

# meaning mo visit ka og page then mo redirect siya sa login kay wla ka naka login
# inig login nimo adto siya mo redirect kong asa ka ni visit na page

# accounts/login.html
	
		{% if request.GET.next %}  <!-- #25 if .next appear in the url like next=/artices/create -->
            <input type="hidden" name="next" value="{{ request.GET.next }}" />  <!-- #25 the will GET the url data like next=/artices/create-->
        {% endif %}

# accounts/views.py

		if 'next' in request.POST:  #25 this will get the .next data of login.html, <input type="hidden" name="next" value="{{ request.GET.next }}" />
		    return redirect(request.POST.get('next'))  #25 then redirect to this path next=/artices/create
		else:
		   return redirect('articles:list')





#---------- #26 model form - or input fields and image and save to database ----------

# articles/forms.py

		from django import forms
		from . import models  # or models.py

		class CreateArticle(forms.ModelForm):
		    class Meta:
		        model = models.Article  # models.py/class Article
		        fields = ['title', 'body', 'slug', 'thumb',]  # models.py/class Article/object of the class

# articles/views.py
		
		from django.shortcuts import render, redirect  #26
		from . import forms  #26 articles/forms.py

		def article_create(request):
	    if request.method == 'POST':  #26 
	        form = forms.CreateArticle(request.POST, request.FILES)  #26 forms.CreateArticle or forms.py/class CreateArticle
	        if form.is_valid():
	            # save article to db
	            return redirect('articles:list')
	    else:
	        form = forms.CreateArticle()
	    return render(request, 'articles/article_create.html', { 'form': form })  #26 redirect to create forms

# articles/article_create.py
		
		{% extends 'base_layout.html' %}

		{% block content %}
		    <div class="create-article">
		        <h2>Create an Awesome New Article</h2>
		        <form class="site-form" action="{% url 'articles:create' %}" method="post" enctype="multipart/form-data">  <!-- #26 send data to artilces/urls.py/app_name = 'articles' using action="{% url 'articles:create' %}" -->
		            {% csrf_token %}
		            {{ form }}  <!-- #26 is in articles/views.py return render(request, 'articles/article_create.html', { 'form': form }) -->
		            			<!-- #26 display forms ui here -->
		            <input type="submit" value="Create">
		        </form>
		    </div>
		{% endblock %}





#---------- #27 foreign key - maka insert og data si specific user ----------

# articles/models.py

		from django.contrib.auth.models import User  #27

		class Article(models.Model):
	    	author = models.ForeignKey(User, default=None)  #27

# NOTE: - delete all data in articles or post in the admin ui
#		- python manage.py makemigrations
#		- python manage.py migrate
#		- python manage.py runserver
#		- refresh the artices page in admin, now you will see the author fields or a dummy names you can use to pratice foreign key

# articles/views.py

		def article_create(request):
		    if request.method == 'POST':
		        form = forms.CreateArticle(request.POST, request.FILES)
		        if form.is_valid():
		            # save article to db
		            instance = form.save(commit=False)  #27 save(commit=False) temporary save
		            instance.author = request.user  #27
		            instance.save()  #27
		            return redirect('articles:list')  #27
		    else:
		        form = forms.CreateArticle()
		    return render(request, 'articles/article_create.html', { 'form': form })





#---------- #28 checking login status - if login show the logout botton  ----------

# base_layout.html

		<nav>
            <ul>
                {% if user.is_authenticated %}
                <li>
                    <form class="logout-link" action="{% url 'accounts:logout' %}" method="post">
                        {% csrf_token %}
                        <button type="submit">Logout</button>
                    </form>
                </li>
                <li><a href="{% url 'articles:create' %}" class="highlight">New Article</a></li>
                {% else %}
                <li><a href="{% url 'accounts:login' %}">Login</a></li>
                <li><a href="{% url 'accounts:signup' %}">Signup</a></li>
                {% endif %}
            </ul>
        </nav>





#---------- #29 redirect to homepage or when click logo link to home page ----------

# firstproject/urls.py

		from articles import views as article_views  #29

		urlpatterns = [
	    url(r'^$', article_views.article_list, name="home"),  #29
	]

# base_layout.html
		
		<h1><a href="{% url 'home' %}"><img src="{% static 'logo.png' %}" alt="djangonautic" /></a></h1>  <!--   #29 -->





#---------- #30 display username or author who add or post articles ----------

# articles/article_list.html

		<div class="articles">
	    {% for article in articles %}
	        <div class="article">
	            <h2><a href="{% url 'articles:detail' slug=article.slug %}">{{ article.title }}</a></h2>
	            <p>{{ article.snippet }}</p>
	            <p>{{ article.date }}</p>
	            <p class="author">added by {{ article.author.username }}</p>  <!-- #30 -->
	        </div>
	    {% endfor %}
	    </div>

		

