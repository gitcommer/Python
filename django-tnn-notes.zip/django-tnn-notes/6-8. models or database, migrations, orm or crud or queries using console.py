
#01. create database table and columns in models.py

	# NOTE:	- when create new project naana siya models.py daan

	from django.db import models

	# Create your models here.
	class Article(models.Model):  # class Article - table name
	    title = models.CharField(max_length=100)  # title - column name
	    slug = models.SlugField()
	    body = models.TextField()
	    date = models.DateTimeField(auto_now_add=True)
	    # add in thumbnail later
	    # add in author later

		#5.0
		def __str__(self): 		# this is use para mo display ang table name sa consold inig display sa data
			return self.title


#2. migrate the database
	
	# C:\Users\TAE\Desktop\django-notes\djangoproject - python manage.py migrate


#3. create a migration file like where you can test database in console
	
	# C:\Users\TAE\Desktop\django-notes\djangoproject - python manage.py makemigrations

			# - this will create 0001_initial.py file in 'migrations folder'

			# - python manage.py migrate (run this always eveytime naakay changes sa models)

	# - this will track or update all changes in the models


#4 ORM or CRUD 	- it bridges the code and the database

	# C:\Users\TAE\Desktop\django-notes\djangoproject - python manage.py shell
	# 		- this will open an interactive shell where you can crud database using console
	#			
	#	cmd:	---sample1---			
	#			- from articles.models import Article 	- articles(project folder), models(models.py), Article(class) same sa python file like .py
	# 	 		- articles 								- run
	# 			- <class 'articles.models.Article'> 	- mao ning naa sa file meaning makita nimo if that file exist

	#			---sample2---
	#			- Article.objects.all() 				- dispaly [], this will check if naay column and table
	#
	#			---sample3---
	#			- article = Article()					- create instance object
	#			- article 								- run
	#			- <Article: Article object (None)>		- output
	#
	#			---sample4 (insert data to database)---
	#			- article.title = "hello world"			- create instance object
	#			- article.title							- run
	#			- 'hello world'							- output
	#			- article.save() 						- insert hello world to database
	#			- Article.objects.all()					- display all data inserted
	#			- Article.objects.all()[0].title 		- use this to display only one data


#5.1			---sample1----
#				- python manage.py shell
#				- from articles.models import Article
#				- Article.objects.all()

#				---sample3----
#				- aritcle2 = Article()
#				- aritcle2.title = "Django Rules"
#				- article2.save()
#				- Article.objects.all()
