#1 articles/views.py

from django.http import HttResponse
from django.shortcuts import render
from .models import Article   #01 .models(models.py) Article is the class Article in models.py

# Create your views here.
def article_list(request):

	#02 get all in the database the data of article and order by date
	articles = Article.objects.all.order_by('date')

	#03 displlay database data to article_list.html
	return render(request, 'articles/article_list.html', {'articles':articles})

def article_detail(request, slug):
	# return HttpResponse(slug)
	article = Article.objects.get(slug=slug)
	return render(request, 'articles/article_list.html', {'articles':articles})


#2 articles/template/articles/artice_detail.py

{% extends 'base_layout.html' %}

{% block content %}
<div class="article-detail">
	<div class="article">
		<h2>{{ article.title }}</h2>
		<p>{{ article.body }}</p>
		<p>{{ article.date }}</p>
	</div>
</div>
{% endblock %}


#3 articles/models.py

from django.db import models

# Create your models here.
class Article(models.Model):
	title = models.CharField(max_length=100)
	slug = models.SlugField()
	body = models.TextField()
	date = models.DateTimeField(auto_now_add=True)

	def __str__(self):
		return self.title

	def snippet(self):
		return self.body[:50] + '...' #2 display only 0-50 character in body