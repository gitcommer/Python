#1 	add this to articlesproject/urls.py
	
	app_name = 'articles' 	#0001

	urlpatterns = [
		url(r'^$', views.article_list, name="list"), 	#01 add the name="" in every to parameter
		url(r'^(?P<slug>[\w-]+)/$', views.article_detail, name="detail"), 	#002
	]


#2 	firstproject/templates/base_layout.html

	<body>
		<div class="wrapper">
			<h1><a href="{% url'list' %}"><img src="{% static 'logo.png' %}"></a></h1> 	#02 add this code
			#or
			<h1><a href="{% url'articles:list' %}"><img src="{% static 'logo.png' %}"></a></h1> 	#0003


#3 	articles/templates/articles/article_list.html

	<body>
		<div class="wrapper">
			<h1><a href="{% url'detail' slug=article.slug %}"><img src="{{ article.title }}"></a></h1> 	#002
			#or
			<h1><a href="{% url'articles:detail' slug=article.slug %}"><img src="{{ article.title }}"></a></h1> 	#0002