
#1 ---articles/views.py---

from django.shortcuts import render
from .models import Article   #01 .models(models.py) Article is the class Article in models.py

def article_list(request):

	#01 get all in the database the data of article and order by date
    articles = Article.objects.all().order_by('date');

    #01 display database data to article_list.html
    return render(request, 'articles/article_list.html', { 'articles': articles })


#2 ---articles/templates/articles/article_list.html---

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>
        <h1>Articles List</h1>
        <div class="articles">
        {% for article in articles %}
            <div class="article">
                <h2><a href="#">{{ article.title }}</a></h2>
                <p>{{ article.body }}</p>
                <p>{{ article.date }}</p>
            </div>
        {% endfor %}
        </div>
    </body>
</html>


#3
# note:	{% code %} 		- use this for python code
# 		{{ db data }}	- use this to output database data

# output data: localhost:8000/articles