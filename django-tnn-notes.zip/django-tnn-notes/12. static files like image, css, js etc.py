#1 	projectfolder/urls.py

from django.conf.urls import url, include
from django.contrib import admin
from.import views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns  #01

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^articles/', include('articles.urls')),
    url(r'^about/$',views.about),
    url(r'^$', views.homepage),
]

urlpatterns += staticfiles_urlpatterns()  #02


#2 	projectfolder/settings.py find and add this code

STATIC_URL = '/static/'

STATICFILES_DIRS = (
    os.path.join(BASE_DIR, 'assets'),
)


#3 	projectfolder/settings.py

	STATIC_URL = '/static/'  # in the url kay localhost:800/static/style.css

	STATICFILES_DIRS = (
    os.path.join(BASE_DIR, 'assets'),
	)


#4 	create assets/styles.css in the projectfolder


#5 	article_list.html and add

	{% load static from staticfiles %}  #001 kong naay usbon sa css link kay mogana lang gihapon tungod ani na code
	<!DOCTYPE html>

	<head>
		<link rel="stylesheet" href="/static/styles.css">
		#or
		<link rel="stylesheet" href="{% static 'styles.css' %}">  #002