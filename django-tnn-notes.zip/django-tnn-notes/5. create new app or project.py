
# NOTE: what will happen here is naaka sa firstproject then pwede ka maka link sa articles project

# 1. 	- C:\Users\TAE\Desktop\django-notes\djangoproject   # kinahanglan naaka sa root or mother folder
# 	 	- cmd/python manage.py startapp articles 			# create new project or app and name it articles

#2. 	create urls.py if not in the new project created and add this code

		from django.conf.urls import url
		from.import views  # from. meaning si views.py same ra og folder ni urls.py

		urlpatterns = [
		    url(r'^$', views.article_list),  #default home page
		]

#3. 	add the to views.py

		from django.shortcuts import render

		def article_list(request):
		    return render(request, 'articles/article_list.html')


#4. 	create html in articles(other project)/templates(folder)/articles(folder)/article.html

		<!DOCTYPE html>
		<html>
		<head>
			<title>Article List</title>
		</head>
		<body>
			<h1>Article List</h1>
		</body>
		</html>

#5. 	note:  - when create new project, register it in the 'other project' settings.py
		INSTALLED_APPS = [
			'articles', 		# add this on the list, this is the folder name of the project
		]

#6. 	 note:  - register the 'articles' project to other project para ma load siya sa browser like
#		 - other project folder/urls.py

#				from django.conf.urls import url, include

#				url(r'^articles/', include('articles.urls'))

#7.		# run the server:   - C:\Users\TAE\Desktop\django-notes\djangoproject - python manage.py runserver