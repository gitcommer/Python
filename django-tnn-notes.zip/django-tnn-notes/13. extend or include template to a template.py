#1 	create base_layout.html in firstproject/templates/base_layout.html

	# base_layout.html 

	{% load static from staticfiles %}

	<!DOCTYPE html>
	<html>
	<head>
		<title></title>
		<link rel="stylesheet" href="{% static 'styles.css' %}">
	</head>
	<body>
		<div class="wrapper">
			{% block content %}

			{% endblock %}
		</div>
	</body>
	</html>


#2 	articlesproject/templates/articles/article_list.html

	# note: moa rani dapat iyang data

	{% extends 'base_layout.html' %}
	
	{% block content %}
		<h1>Article List</h1>
		<div class="article">
			{% for article in articles %}
				<div class="article">
					<h2><a href="#">{{ article.tile }}</a></h2>
					<p><a href="#">{{ article.snippet }}</a></p>  <!--03-->
					<p><a href="#">{{ article.date }}</a></p>
				</div>
			{% endfor %}
		</div>
	{% endblock %}



